THIS MOD (THAT YOU PROBABLY ALREADY HAVE) IS NEEDED. : https://nfsmods.xyz/mod/2694
put the asi in the scripts folder and whabam no more drifting!
all credit for the ported code goes to the overhaul mod and its creator : https://github.com/mRally2/Most-Wanted-Overhauled/tree/main